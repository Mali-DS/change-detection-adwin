import meka.classifiers.MultiXClassifier;
import meka.classifiers.multilabel.Evaluation;
import meka.classifiers.multiltarget.incremental.CRUpdateable;
import meka.core.Result;
import meka.filters.unsupervised.attribute.MekaClassAttributes;
import moa.classifiers.core.driftdetection.ADWIN;
import weka.attributeSelection.AttributeSelection;
import weka.attributeSelection.PrincipalComponents;
import weka.attributeSelection.Ranker;
import weka.attributeSelection.ReliefFAttributeEval;
import weka.classifiers.Classifier;
import weka.classifiers.functions.SGD;
import weka.classifiers.trees.HoeffdingTree;
import weka.classifiers.trees.M5P;
import weka.classifiers.trees.RandomForest;
import weka.core.*;
import weka.core.converters.*;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.unsupervised.attribute.RemoveType;
import weka.gui.treevisualizer.PlaceNode2;
import weka.gui.treevisualizer.TreeVisualizer;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.util.*;



public class MultiTargetRegByMeka {

    public static final String RAW_DATA= "/Users/ali/Desktop/COMPSCI791A/WAS_Merge_110-536_20180112_TS_EDITED_Preparation.arff";
    public static final String FILE_PATH = "/Users/ali/Desktop/COMPSCI791A/Missing_values_Predicted.arff";
    public static final String PREPARED_DATA_SECONDS = "/Users/ali/Desktop/COMPSCI791A/Missing_values_Predicted_Seconds.arff";
    public static final String DATASET_NO_TIME_ATT = "/Users/ali/Desktop/COMPSCI791A/Missing_values_Predicted_NoTimeAtt.arff";
    public static final String ETHANE_AS_TARGET_DATASET = "/Users/ali/Desktop/COMPSCI791A/2009_2012SingleDataset/EthaneAsTargetDatasetConvertDate2009_2012.arff";
    public static final String NBUTANE_AS_TARGET_DATASET = "/Users/ali/Desktop/COMPSCI791A/2009_2012SingleDataset/NButaneAsTargetDatasetConvertDate2009_2012.arff";
    public static final String NPENTANE_AS_TARGET_DATASET = "/Users/ali/Desktop/COMPSCI791A/2009_2012SingleDataset/NPentaneAsTargetDatasetConvertDate2009_2012.arff";
    public static final String PROPANE_AS_TARGET_DATASET = "/Users/ali/Desktop/COMPSCI791A/2009_2012SingleDataset/PropaneAsTargetDatasetConvertDate2009_2012.arff";
    public static final String BENZENE_AS_TARGET_DATASET = "/Users/ali/Desktop/COMPSCI791A/2009_2012SingleDataset/BenzeneAsTargetDatasetConvertDate2009_2012.arff";
    public static final String IBUTANE_AS_TARGET_DATASET = "/Users/ali/Desktop/COMPSCI791A/2009_2012SingleDataset/IButaneAsTargetDatasetConvertDate2009_2012.arff";
    public static final String IPENTANE_AS_TARGET_DATASET = "/Users/ali/Desktop/COMPSCI791A/2009_2012SingleDataset/IPentaneAsTargetDatasetConvertDate2009_2012.arff";
    public static final String PREPARED_DATA_2009_TO_2012="/Users/ali/Desktop/COMPSCI791A/Missing_values_Predicted_Seconds_2009_2011.arff";
    public static final String PREPARED_DATA_NODATE_2009_2012 = "/Users/ali/Desktop/COMPSCI791A/Missing_values_Predicted_Seconds_NoDate_2009_2011.arff";
    public static final String PREPARED_DATA_NODATE_CONVERTDATE2009_2012 ="/Users/ali/Desktop/COMPSCI791A/Missing_values_Predicted_Seconds_ConvertDate2009_2011.arff";
    public static final String ACTUALS_PREDICTIONS_FILE_PATH = "/Users/ali/Desktop/COMPSCI791A/ActualsPredictionsDataset.csv";
    public static final String ACTUALS_PREDICTIONS_FILE_PATH_BY_FRS = "/Users/ali/Desktop/COMPSCI791A/ActualsPredictionsDatasetByFRs.csv";
    public static final String TARGETS_RESIDUALS= "/Users/ali/Desktop/COMPSCI791A/M5PResiduals4Adwin.arff";
    public static final String DATASETREMOVED4ATTS = "/Users/ali/Desktop/COMPSCI791A/Missing_values_Predicted_Remove4Atts.arff";

    public static final String EACH_500_EVALUATION_FILE_PATH = "/Users/ali/Desktop/COMPSCI791A/Each500EvaluationResult.csv";
    public static final String EACH_500_visualization_FILE_PATH = "/Users/ali/Desktop/COMPSCI791A/Each500Visualization.txt";

    public static final String EUROPE_SQURE_FILE_PATH = "/Users/ali/Desktop/COMPSCI791A/EuropeAndNearbyDataSet.arff";    //592 RECORDS
    public static final String EUROPE_BYNAME_FILE_PATH = "/Users/ali/Desktop/COMPSCI791A/EuropeDataSet.arff";            // 724 records
    public static final String EUROPE_EXTENDED_FILE_PATH = "/Users/ali/Desktop/COMPSCI791A/EuropeAndNearbyExtendedDataSet.arff";    // 973 records
    public static final String DATASET_CONVERTED_DATE_TIME_NOFLIGHT_NOSAMPLE = "/Users/ali/Desktop/COMPSCI791A/Missing_values_Predicted_ConvertedDateTimeNoFS.arff";
    public static final String DATASET_SELECTED_ATTRIBUTES = "/Users/ali/Desktop/COMPSCI791A/Missing_values_Predicted_selectedAtts.arff";
    public static final String ORIGINAL_FILE_PATH = "/Users/ali/Desktop/COMPSCI791A/OriginalDatasetForEvaluation.arff";
    public static final String[] europeanCountries = {
        "AUT", // Austria
        "BEL", // Belgium
        "BGR", // Bulgaria
        "HRV", // Croatia
        "CYP", // Cyprus
        "CZE", // Czech Republic
        "DNK", // Denmark
        "EST", // Estonia
        "FIN", // Finland
        "FRA", // France
        "DEU", // Germany
        "GRC", // Greece
        "HUN", // Hungary
        "IRL", // Ireland
        "ITA", // Italy
        "LVA", // Latvia
        "LTU", // Lithuania
        "LUX", // Luxembourg
        "MLT", // Malta
        "NLD", // Netherlands
        "POL", // Poland
        "PRT", // Portugal
        "ROU", // Romania
        "SVK", // Slovakia
        "SVN", // Slovenia
        "ESP", // Spain
        "SWE", // Sweden
        "GBR", // United Kingdom
    };
    public static final int NUMBER_OF_TREES = 100;   // 500 and 5 out of memory
    public static final int DEPTH_OF_TREES = 4;
    public static final int MIN_VARIANCE_FOR_SPLIT =100;

    public static void main(String[] args) throws java.lang.Exception {
//        multiTargetRegByThreeMonths("/Users/ali/Desktop/COMPSCI791A/Eval3MonthsLDNoUC");
//        multiTargetRegByYear("/Users/ali/Desktop/COMPSCI791A/Eval1YearNoUC");
//        evaluateOriginalDatasetBySGD("/Users/ali/Desktop/COMPSCI791A/EvalOriginalDSTrainedByNewTrainingDSNoUC");
//        extractedEuropeData(FILE_PATH , "/Users/ali/Desktop/COMPSCI791A/EuropeAndNearbyExtendedDataSet");
//        evaluateOriginalDatasetByRF("/Users/ali/Desktop/COMPSCI791A/EvalOriginalDSByRF" );
//        evaluateOriginalDatasetByDT( FILE_PATH,100,0);
//        changeDetectionByAdwin("/Users/ali/Desktop/COMPSCI791A/AdwinResult" );
//        predictByM5PPerAdwinDetectionPoint("/Users/ali/Desktop/COMPSCI791A/predictByM5PPerAdwinDetectionPoint");
//        trainByWholeDataset();
        /////////////////////// 12 April ///////////////////////////////////
//        evaluateOriginalDatasetByM5P("/Users/ali/Desktop/COMPSCI791A/EvalOriginalDSByM5P");
//        rankingAttributes();
//        PCA();
//        trainByWholeDatasetIn1Step();
        /////////////////////// 10 May ///////////////////////////////////
        predictBySelectedAttributes();
    }


    /**
     * this method is doing multi target regression using original dataset per each year
     * @param path
     */
    public static void multiTargetRegByYear(String path) {
        int countTrainInstances = 0;
        boolean firstTrain = true;
        boolean setStartMonth = true;
        boolean setUpadateDate = true;
        String startMonth = null;
        String updateDate = null;
        String testDate = null;

        try {
            ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(FILE_PATH); // original dataset
            Instances preparedDataSet = dataSource.getDataSet();

            CRUpdateable classifier = new CRUpdateable();// the default classifier of CRUpdateable is Hoeffding Tree
            SGD sgd = new SGD();
            String[] sgdOptions = new String[2];
            sgdOptions[0] = "-F";
            sgdOptions[1] = "4";
            sgd.setOptions(sgdOptions);
            classifier.setClassifier(sgd);
            Instances output = new Instances(dataSource.getStructure());
            Instances tempInstances = new Instances(dataSource.getStructure());
            Instances trainingInstances = new Instances(dataSource.getStructure()); // temporary dataset for train
            int totalMonthsNum = 0;
            Instances evalResultDataset = createEvaluationResultDataset();
            System.out.println("total instances: " + preparedDataSet.numInstances());
            for (int row = 0; row < preparedDataSet.numInstances(); row++) {// start from row 123 to ignore missing values    // End at 5021, we have two version, another one is from 5021 till last instance

                Instance trainingInstance = preparedDataSet.instance(row);
                if (setStartMonth) {
                    startMonth = trainingInstance.stringValue(17);
                    setStartMonth = false;
                }
                if (firstTrain) {
                    if (getOneYearData(trainingInstance, startMonth)) { // collect 12 months records to build classifier
                        trainingInstances.add(trainingInstance); // collect instances to use as training
                        countTrainInstances++;
                    } else {
                        trainingInstances = PrepareClassAttributes(trainingInstances, "1,2,3,4,5,6,7"); // Set which attributes are to be used as MEKA class attributes.
                        firstTrain = false;
                        classifier.buildClassifier(removeNonNumeric(trainingInstances, "18,19"));
                        System.out.println("second year start for test :" + trainingInstance.stringValue(17));
                        testByOneYear(preparedDataSet, row, output, evalResultDataset, classifier, trainingInstance.stringValue(17), path);

                    }


                }
                if (!firstTrain) {
                    if (setUpadateDate) {
                        updateDate = trainingInstance.stringValue(17);
                        System.out.println("updateDate :" + updateDate);
                        setUpadateDate = false;
                        totalMonthsNum++;
                    }
                    if (!setUpadateDate) {
                        if (getOneYearData(trainingInstance, updateDate)) {
                            trainingInstance.setDataset(trainingInstances);
                            tempInstances.add(trainingInstance);
                            trainingInstances.add(removeNonNumeric(tempInstances, "18,19").get(0)); // collect next month instances to use as updating Classifier
                            Instance instanceToUpdate = removeNonNumeric(tempInstances, "18,19").get(0);
                            instanceToUpdate.setDataset(trainingInstances);
//                            classifier.updateClassifier(instanceToUpdate); // measure onetime with update classifier and onetime without classifier
                            tempInstances.delete();
                            countTrainInstances++;
                        } else {
                            setUpadateDate = true;
                            testDate = trainingInstance.stringValue(17);
                            trainingInstances = PrepareClassAttributes(trainingInstances, "1,2,3,4,5,6,7"); // Set which attributes are to be used as MEKA class attributes.
                            testByOneYear(preparedDataSet, row, output, evalResultDataset, classifier, testDate, path);
                        }
                    }
                }
            }
            System.out.println("totalMonthsNum : " + totalMonthsNum);
            System.out.println("countTrainInstances : " + countTrainInstances);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * this method is doing multi target regression using original dataset per three months
     * @param path
     */
    public static void multiTargetRegByThreeMonths(String path ) {
        int countTrainInstances = 0;
        boolean firstTrain = true;
        boolean setFirstMonthDate = true;
        boolean setUpadateDate = true;
        String firstMonthDate = null;
        String updateDate = null;
        String testDate = null;

        try {
            ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(FILE_PATH); // original dataset
            Instances preparedDataSet = dataSource.getDataSet();

            CRUpdateable classifier = new CRUpdateable();// the default classifier of CRUpdateable is Hoeffding Tree
            SGD sgd = new SGD();
            String[] sgdOptions = new String[2];
            sgdOptions[0] = "-F";
            sgdOptions[1] = "4";
            sgd.setOptions(sgdOptions);
            classifier.setClassifier(sgd);
            Instances output = new Instances(dataSource.getStructure());
            Instances tempInstances = new Instances(dataSource.getStructure());
            Instances trainingInstances = new Instances(dataSource.getStructure()); // temporary dataset for train
            int totalMonthsNum = 0;
            Instances evalResultDataset = createEvaluationResultDataset();
            System.out.println("total instances: " + preparedDataSet.numInstances());
            for (int row = 0; row < preparedDataSet.numInstances(); row++) {

                Instance trainingInstance = preparedDataSet.instance(row);
                if (setFirstMonthDate) {
                    firstMonthDate = trainingInstance.stringValue(17);
                    setFirstMonthDate = false;
                }
                if (firstTrain && !setFirstMonthDate) {
                    if (getOneMonthData(trainingInstance, firstMonthDate)) { // collect one month records to build classifier
                        trainingInstances.add(trainingInstance); // collect instances to use as training
                        countTrainInstances++;
                    } else {  // train the classifier with the first MONTH instances(without any missing values)
                        trainingInstances = PrepareClassAttributes(trainingInstances, "1,2,3,4,5,6,7"); // Set which attributes are to be used as MEKA class attributes.
                        firstTrain = false;
                        classifier.buildClassifier(removeNonNumeric(trainingInstances, "18,19"));
                        testByMonths(preparedDataSet,row,output,evalResultDataset,classifier,trainingInstance.stringValue(17),path,3);
                    }
                }


                if (!firstTrain) {
                    if (setUpadateDate) {
                        updateDate = trainingInstance.stringValue(17);
                        System.out.println("updateDate :" + updateDate);
                        setUpadateDate = false;
                        totalMonthsNum++;
                    }
                    if (getOneMonthData(trainingInstance, updateDate)) {
                        trainingInstance.setDataset(trainingInstances);
                        tempInstances.add(trainingInstance);
                        trainingInstances.add(removeNonNumeric(tempInstances, "18,19").get(0)); // collect next month instances to use as updating Classifier
                        Instance instanceToUpdate = removeNonNumeric(tempInstances, "18,19").get(0);
                        instanceToUpdate.setDataset(trainingInstances);
//                        classifier.updateClassifier(instanceToUpdate); // measure onetime with update classifier and onetime without classifier
                        tempInstances.delete();
                        countTrainInstances++;
                    } else {
                        setUpadateDate = true;
                        testDate = trainingInstance.stringValue(17);

                        testByMonths(preparedDataSet,row,output,evalResultDataset,classifier,testDate,path,3);

                    }

                }
            }
            System.out.println("totalMonthsNum : " + totalMonthsNum);
            System.out.println("countTrainInstances : " + countTrainInstances);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * this method is doing multi target regression using original dataset per one month
     * @param path
     */
    public static void evaluateOriginalDatasetBySGD(String path ) {
        int countTrainInstances = 0;
        boolean firstTrain = true;
        boolean setFirstMonthDate = true;
        boolean setUpadateDate = true;
        String firstMonthDate = null;
        String updateDate = null;
        String testDate = null;
        int evalStartIndex = 0;
        int lastIndex = 0;

        int index = 0;

        try {
            ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(FILE_PATH); // original dataset

            Instances preparedDataSet = dataSource.getDataSet();

            ConverterUtils.DataSource originalDataSource = new ConverterUtils.DataSource(ORIGINAL_FILE_PATH); // ORIGINAL dataset
            Instances originalDataSet = originalDataSource.getDataSet();


            CRUpdateable classifier = new CRUpdateable();// the default classifier of CRUpdateable is Hoeffding Tree
            SGD sgd = new SGD();
            String[] sgdOptions = new String[4];
            sgdOptions[0] = "-F";
            sgdOptions[1] = "2";
            sgdOptions[2] = "-L";
            sgdOptions[3] = "0.0001";
            sgd.setOptions(sgdOptions);
            classifier.setClassifier(sgd);
            Instances output = new Instances(originalDataSource.getStructure());
//            Instances evalResult = new Instances(originalDataSource.getStructure());
            Instances dataForEval = new Instances(originalDataSource.getStructure());
            Instances tempInstances = new Instances(dataSource.getStructure());
            Instances trainingInstances = new Instances(dataSource.getStructure()); // temporary dataset for train
            int totalMonthsNum = 0;
            Instances evalResultDataset = createEvaluationResultDataset();
            System.out.println("total instances: " + preparedDataSet.numInstances());
            ArrayList<double[]> temporarySpaceToWrite = new ArrayList<double[]>() ;
            for (int row = 0; row < preparedDataSet.numInstances(); row++) {

                Instance trainingInstance = preparedDataSet.instance(row);
                if (setFirstMonthDate) {
                    firstMonthDate = trainingInstance.stringValue(17);
                    setFirstMonthDate = false;
                }
                if (firstTrain && !setFirstMonthDate) {
                    if (getOneMonthData(trainingInstance, firstMonthDate)) { // collect one month records to build classifier
                        trainingInstances.add(trainingInstance); // collect instances to use as training
                        countTrainInstances++;
                    } else {  // train the classifier with the first MONTH instances(without any missing values)
                        trainingInstances = PrepareClassAttributes(trainingInstances, "1,2,3,4,5,6,7"); // Set which attributes are to be used as MEKA class attributes.
                        firstTrain = false;
                        classifier.buildClassifier(removeNonNumeric(trainingInstances, "18,19"));
//                        testByMonths(preparedDataSet,row,output,evalResultDataset,classifier,trainingInstance.stringValue(17),path,3);
                    }
                }


                if (!firstTrain) {
                    if (setUpadateDate) {
                        updateDate = trainingInstance.stringValue(17);
                        System.out.println("updateDate :" + updateDate);
                        setUpadateDate = false;
                        totalMonthsNum++;
                    }
                    if (getOneMonthData(trainingInstance, updateDate)) {
                        trainingInstance.setDataset(trainingInstances);
                        tempInstances.add(trainingInstance);
                        trainingInstances.add(removeNonNumeric(tempInstances, "18,19").get(0)); // collect next month instances to use as updating Classifier
                        Instance instanceToUpdate = removeNonNumeric(tempInstances, "18,19").get(0);
                        instanceToUpdate.setDataset(trainingInstances);
                        classifier.updateClassifier(instanceToUpdate); // measure onetime with update classifier and onetime without classifier
                        tempInstances.delete();
                        countTrainInstances++;
                    } else {
                        setUpadateDate = true;



                        for(int j=0;j<3;j++){
                            if(j==0) dataForEval = getDataByMoreMonths(originalDataSet,index,output,1);
                            if(j==1) {
                                lastIndex = evalStartIndex;
                                evalStartIndex = evalStartIndex + dataForEval.size();
                                dataForEval = getDataByMoreMonths(originalDataSet,evalStartIndex,output,1);
                            }
                            if(j==2){
                                dataForEval = getDataByMoreMonths(originalDataSet,lastIndex + dataForEval.size(),output,1);
                            }


                        }
                        index = evalStartIndex;
                        if(dataForEval.size() !=0){
                            String evalDate = dataForEval.get(0).stringValue(17);
                            dataForEval = PrepareClassAttributes(dataForEval, "1,2,3,4,5,6,7");
                            String top = "PCut1"; // Threshold OPtion  PCut1 or PCutl
                            String vop = "4";  //Specify more/less evaluation output
                            dataForEval = removeNonNumeric(dataForEval, "18,19");
//                            System.out.println("dataForEval.numAttributes() ===> "+dataForEval.get(0).numAttributes());
                            System.out.println("dataForEval : "+dataForEval.size());
                            Result result = Evaluation.evaluateModel((MultiXClassifier) classifier,dataForEval, top, vop);
                            System.out.println("Evaluation Info: " + result.toString());

                            double longitudeVariance = round(dataForEval.variance(17),4);
                            double latitudeVariance = round(dataForEval.variance(18),4);
                            double altitudeVariance = round(dataForEval.variance(19),4);
                            double longitudeMean = round(dataForEval.meanOrMode(17),4);
                            double latitudeMean = round(dataForEval.meanOrMode(18),4);
                            double altitudeMean = round(dataForEval.meanOrMode(19),4);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                            double[][] realValues = new double[dataForEval.size()][7];
                            for (int i=0;i<dataForEval.numInstances();i++){
                                Instance realValueInstnce = dataForEval.get(i);
//                                System.out.println("newwwwwwwwww");
                                realValues[i][0] = realValueInstnce.value(0);
                                realValues[i][1] = realValueInstnce.value(1);
                                realValues[i][2] = realValueInstnce.value(2);
                                realValues[i][3] = realValueInstnce.value(3);
                                realValues[i][4] = realValueInstnce.value(4);
                                realValues[i][5] = realValueInstnce.value(5);
                                realValues[i][6] = realValueInstnce.value(6);
//                                System.out.print(realValues[i][0] + "\t");
//                                System.out.print(realValues[i][1] + "\t");
//                                System.out.print(realValues[i][2] + "\t");
//                                System.out.print(realValues[i][3] + "\t");
//                                System.out.print(realValues[i][4] + "\t");
//                                System.out.print(realValues[i][5] + "\t");
//                                System.out.print(realValues[i][6] + "\t");

                            }
                            double[][] mergeActualsPredictions = mergeActualsAndPredictions(realValues, result.allPredictions()); // allPrediction returns prediction confidence( the capacity of the model to achieve the same performance when it is applied to a new data set)
                            for(int m =0;m<mergeActualsPredictions.length;m++){
                                temporarySpaceToWrite.add(mergeActualsPredictions[m]);

                            }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////


                            saveEvaluationResult(evalResultDataset, evalDate, round(((Double) result.getMeasurement("Hamming score")).doubleValue(), 4),
                                    dataForEval.numInstances(), path , longitudeVariance, latitudeVariance, altitudeVariance,longitudeMean, latitudeMean, altitudeMean);
                            dataForEval.delete();
                            output.delete();
                        }
                    }

                }
            }
            BufferedWriter br = new BufferedWriter(new FileWriter(ACTUALS_PREDICTIONS_FILE_PATH));
            writeActualPredictionsInCsvFile(br, temporarySpaceToWrite);
            br.close();
            System.out.println("totalMonthsNum : " + totalMonthsNum);
            System.out.println("countTrainInstances : " + countTrainInstances);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * this method is doing multi target regression using 2009_TO_2012 dataset
     * save predicted values every 250 rows to use as training instances for the next 250 inatances.
     * @param path
     */
    public static void evaluateOriginalDatasetByRF(String path ) throws java.lang.Exception {
        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(PREPARED_DATA_2009_TO_2012);
        Instances originalDataSet = dataSource.getDataSet();

        Instances trainingData = new Instances(dataSource.getStructure());

        Instances predictedDataset = dataSource.getDataSet();
        originalDataSet = filterUnsupervisedAttributes(originalDataSet);
        predictedDataset = filterUnsupervisedAttributes(predictedDataset);
        trainingData = filterUnsupervisedAttributes(trainingData);

        RandomForest randomForest = createRandomForest(NUMBER_OF_TREES, DEPTH_OF_TREES, MIN_VARIANCE_FOR_SPLIT);
        BufferedWriter br = new BufferedWriter(new FileWriter(EACH_500_EVALUATION_FILE_PATH));
        double[][] temporarySpaceToWrite = new double[100][3] ;
        ArrayList<double[]> realPredictedValues = new ArrayList<double[]>() ;
        int numInst = originalDataSet.numInstances();
        int i = 0;
        int trainingIndex = 0;
        for (int row = 0; row <= numInst; row++) {
            long start = System.currentTimeMillis();
            int numMissingValues = 0;
            if (row > 0 && row % 250 == 0) {
                trainingData = keepLast500Instances(trainingData);
                weka.classifiers.Evaluation eval = new weka.classifiers.Evaluation(trainingData);
                eval.evaluateModel(randomForest, predictedDataset);
                System.out.println(eval.toSummaryString("\nResults\n========================================\n", true));
                temporarySpaceToWrite[i][0]=row;
                temporarySpaceToWrite[i][1]=round(eval.meanAbsoluteError(),2);
                temporarySpaceToWrite[i][2]=round(eval.rootMeanSquaredError(),2);
                i++;

                randomForest = createRandomForest(NUMBER_OF_TREES, DEPTH_OF_TREES, MIN_VARIANCE_FOR_SPLIT);
                // change to create 250 training data blocks
                saveDataSet(trainingData, "/Users/ali/Desktop/COMPSCI791A/Predicted_First_" + row + "_rows");
            }
            trainingIndex = trainingData.size();

            Instance originInstance = (Instance) originalDataSet.instance(row).copy();
            trainingData.add(originInstance);


            if (predictTargetColumn(originalDataSet, trainingData, row , trainingIndex, 0, randomForest, predictedDataset))
                numMissingValues++;
            if (predictTargetColumn(originalDataSet, trainingData, row , trainingIndex, 1, randomForest, predictedDataset))
                numMissingValues++;
            if (predictTargetColumn(originalDataSet, trainingData, row , trainingIndex, 2, randomForest, predictedDataset))
                numMissingValues++;
            if (predictTargetColumn(originalDataSet, trainingData, row , trainingIndex, 3, randomForest, predictedDataset))
                numMissingValues++;
            if (predictTargetColumn(originalDataSet, trainingData, row , trainingIndex, 4, randomForest, predictedDataset))
                numMissingValues++;
            if (predictTargetColumn(originalDataSet, trainingData, row , trainingIndex, 5, randomForest, predictedDataset))
                numMissingValues++;
            if (predictTargetColumn(originalDataSet, trainingData, row , trainingIndex, 6, randomForest, predictedDataset))
                numMissingValues++;
            trainingIndex++;




                long end = System.currentTimeMillis();
                System.out.println("Row #" + row + " is processed in " + (end - start) + " milllis with " + numMissingValues + " calculated missing values.");
                System.out.println("Original:\t" +
                        originInstance.value(0) + ",\t" +
                        originInstance.value(1) + ",\t" +
                        originInstance.value(2) + ",\t" +
                        originInstance.value(3) + ",\t" +
                        originInstance.value(4) + ",\t" +
                        originInstance.value(5) + ",\t" +
                        originInstance.value(6) + ",\t"
                );

                Instance allPredictedInstance = predictedDataset.instance(row);
                System.out.println("Predicted:\t" +
                        allPredictedInstance.value(0) + ",\t" +
                        allPredictedInstance.value(1) + ",\t" +
                        allPredictedInstance.value(2) + ",\t" +
                        allPredictedInstance.value(3) + ",\t" +
                        allPredictedInstance.value(4) + ",\t" +
                        allPredictedInstance.value(5) + ",\t" +
                        allPredictedInstance.value(6) + ",\t"
                );
                System.out.println("--------------------------------------------------------------------------");
            }

        writeEach500EvalResult( br, temporarySpaceToWrite);
        br.close();



    }

    /**
     * this method is doing multi target regression using original dataset
     * save predicted values every 500 rows to use as training instances for the next 500 inatances.
     * @param path
     */


    public static void evaluateOriginalDatasetByHoeffdingTree(String path ) throws java.lang.Exception {
        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(FILE_PATH);
        Instances originalDataSet = dataSource.getDataSet();

        Instances trainingData = new Instances(dataSource.getStructure());

        Instances predictedDataset = dataSource.getDataSet();
        originalDataSet = filterUnsupervisedAttributes(originalDataSet);
        predictedDataset = filterUnsupervisedAttributes(predictedDataset);
        trainingData = filterUnsupervisedAttributes(trainingData);

        HoeffdingTree hoeffdingTree= new HoeffdingTree();
        String[] htOptions = new String[2];
        htOptions[0] = "-L";
        htOptions[1] = "0";
        hoeffdingTree.setOptions(htOptions);


        BufferedWriter br = new BufferedWriter(new FileWriter(EACH_500_EVALUATION_FILE_PATH));
        double[][] temporarySpaceToWrite = new double[100][3] ;
        ArrayList<double[]> realPredictedValues = new ArrayList<double[]>() ;
        int numInst = originalDataSet.numInstances();
        int i = 0;
        int trainingIndex = 0;
        for (int row = 0; row < numInst; row++) {
            long start = System.currentTimeMillis();
            int numMissingValues = 0;
            // save predicted values every 500 rows to use as training instances for the next 500 inatances.
            if (row > 0 && row % 500 == 0) {
                trainingData = keepLast500Instances(trainingData);
                weka.classifiers.Evaluation eval = new weka.classifiers.Evaluation(trainingData);
                eval.evaluateModel(hoeffdingTree, predictedDataset);
                System.out.println(eval.toSummaryString("\nResults\n========================================\n", true));
                temporarySpaceToWrite[i][0]=row;
                temporarySpaceToWrite[i][1]=round(eval.meanAbsoluteError(),2);
                temporarySpaceToWrite[i][2]=round(eval.rootMeanSquaredError(),2);
                i++;


                saveDataSet(trainingData, "/Users/ali/Desktop/COMPSCI791A/Predicted_First_" + row + "_rows");
                hoeffdingTree = new HoeffdingTree();
            }
            trainingIndex = trainingData.size();

            Instance originInstance = (Instance) originalDataSet.instance(row).copy();
            trainingData.add(originInstance);


            if (predictTargetColumnsByHT(originalDataSet, trainingData, row , trainingIndex, 0, hoeffdingTree, predictedDataset))
                numMissingValues++;
            if (predictTargetColumnsByHT(originalDataSet, trainingData, row , trainingIndex, 1, hoeffdingTree, predictedDataset))
                numMissingValues++;
            if (predictTargetColumnsByHT(originalDataSet, trainingData, row , trainingIndex, 2, hoeffdingTree, predictedDataset))
                numMissingValues++;
            if (predictTargetColumnsByHT(originalDataSet, trainingData, row , trainingIndex, 3, hoeffdingTree, predictedDataset))
                numMissingValues++;
            if (predictTargetColumnsByHT(originalDataSet, trainingData, row , trainingIndex, 4, hoeffdingTree, predictedDataset))
                numMissingValues++;
            if (predictTargetColumnsByHT(originalDataSet, trainingData, row , trainingIndex, 5, hoeffdingTree, predictedDataset))
                numMissingValues++;
            if (predictTargetColumnsByHT(originalDataSet, trainingData, row , trainingIndex, 6, hoeffdingTree, predictedDataset))
                numMissingValues++;
            trainingIndex++;




            long end = System.currentTimeMillis();
            System.out.println("Row #" + row + " is processed in " + (end - start) + " milllis with " + numMissingValues + " calculated missing values.");
            System.out.println("Original:\t" +
                    originInstance.value(0) + ",\t" +
                    originInstance.value(1) + ",\t" +
                    originInstance.value(2) + ",\t" +
                    originInstance.value(3) + ",\t" +
                    originInstance.value(4) + ",\t" +
                    originInstance.value(5) + ",\t" +
                    originInstance.value(6) + ",\t"
            );

            Instance allPredictedInstance = predictedDataset.instance(row);
            System.out.println("Predicted:\t" +
                    allPredictedInstance.value(0) + ",\t" +
                    allPredictedInstance.value(1) + ",\t" +
                    allPredictedInstance.value(2) + ",\t" +
                    allPredictedInstance.value(3) + ",\t" +
                    allPredictedInstance.value(4) + ",\t" +
                    allPredictedInstance.value(5) + ",\t" +
                    allPredictedInstance.value(6) + ",\t"
            );
            System.out.println("--------------------------------------------------------------------------");
        }

        writeEach500EvalResult( br, temporarySpaceToWrite);
        br.close();



    }

    /**
     * This method detecting changes through instances by Adwin
     * @param path
     * @throws java.lang.Exception
     */
    public static void changeDetectionByAdwin2(String path ) throws java.lang.Exception{
        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(TARGETS_RESIDUALS);
        Instances targetResiduals = dataSource.getDataSet();
        BufferedWriter br = new BufferedWriter(new FileWriter(path));
        ArrayList<int[]> listOfResult = new ArrayList<int[]>();
        for(int i=0;i<7;i++){
            int[] adwinResult = new int[100];
            int changeCount = 0;
            ADWIN adwin = new ADWIN();
            for (int row = 0; row < targetResiduals.numInstances(); row++) {
                Instance targetResidualInstance =  targetResiduals.instance(row);
                adwin.setInput(targetResidualInstance.value(i), 0.05);
                if (adwin.getChange()) {
                    System.out.println("point of change = " + adwin.getChange()+" in row "+row);
                    adwinResult[changeCount]= row;
                    changeCount++;
                }

            }
            listOfResult.add(adwinResult);

            System.out.println("numberOfChanges in target :"+i+" ==> "+adwin.getNumberDetections());
        }
        writeAdwinResult(br , listOfResult);

        br.close();
    }

    /**
     * This method detecting changes through instances by Adwin, the diiferences with teh previous one is in generating the output
     * @param path
     * @throws java.lang.Exception
     */
    public static void changeDetectionByAdwin(String path ) throws java.lang.Exception{
        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(TARGETS_RESIDUALS);
        Instances targetResiduals = dataSource.getDataSet();

        ArrayList<boolean[]> listOfResult = new ArrayList<boolean[]>();
        boolean change = false;

        String fileName = "";
        for(int i=0;i<7;i++){
            if(i==0)
                fileName = "Etahne";
            else if(i==1)
                fileName = "NButane";
            else if(i==2)
                fileName = "NPentane";
            else if(i==3)
                fileName = "Propane";
            else if(i==4)
                fileName = "Benzene";
            else if(i==5)
                fileName = "IButane";
            else if(i==6)
                fileName = "IPentane";

            BufferedWriter br = new BufferedWriter(new FileWriter(path+fileName+".csv"));

//            boolean[] adwinResult = new boolean[targetResiduals.size()];
            ADWIN adwin = new ADWIN();
            double[][] result = new double[targetResiduals.size()][1];

            for (int row = 0; row < targetResiduals.numInstances(); row++) {
                Instance targetResidualInstance =  targetResiduals.instance(row);
                adwin.setInput(targetResidualInstance.value(i), 0.00001);

                change =  adwin.getChange();


                if(change == true)
                    result[row][0] = 1;
                else
                    result[row][0] = 0;



            }
            writeAdwinEpsilonAbsvalue(br , result);
            br.close();
//            listOfResult.add(adwinResult);

            System.out.println("numberOfChanges in target :"+i+" ==> "+adwin.getNumberDetections());
        }
//        writeAdwinResult2(br , listOfResult);

    }

    public static Instances PrepareClassAttributes(Instances dataSet, String indecies) {
        Instances output = null;
        try {
            MekaClassAttributes filter = new MekaClassAttributes();  // Reorders attributes for MEKA to use as class attributes.
            filter.setAttributeIndices(indecies); // Set which attributes are to be used as MEKA class attributes.
            filter.setInputFormat(dataSet);
            output = Filter.useFilter(dataSet, filter);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return output;
    }


    public static Instances createEvaluationResultDataset() {


        ArrayList<Attribute> attr = new ArrayList<Attribute>();
        attr.add(new Attribute("row_index", true));
        attr.add(new Attribute("Hamming score"));
        attr.add(new Attribute("instanceNum"));
        attr.add(new Attribute("longitudeVariance"));
        attr.add(new Attribute("latitudeVariance"));
        attr.add(new Attribute("altitudeVariance"));
        attr.add(new Attribute("longitudeMean"));
        attr.add(new Attribute("latitudeMean"));
        attr.add(new Attribute("altitudeMean"));
        Instances instances = new Instances("evalResult", attr, 0);
        return instances;

    }

    public static void saveEvaluationResult(Instances evalResultDataset, String fromTo, double eval, int instanceNum, String path ,  double longitudeVariance, double latitudeVariance, double altitudeVariance, double longitudeMean, double latitudeMean, double altitudeMean) throws Exception {

        double[] instanceValue = new double[evalResultDataset.numAttributes()];

        instanceValue[0] = evalResultDataset.attribute(0).addStringValue(fromTo);
        instanceValue[1] = eval;
        instanceValue[2] = instanceNum;
        instanceValue[3] = longitudeVariance;
        instanceValue[4] = latitudeVariance;
        instanceValue[5] = altitudeVariance;
        instanceValue[6] = longitudeMean;
        instanceValue[7] = latitudeMean;
        instanceValue[8] = altitudeMean;

        evalResultDataset.add(new DenseInstance(1.0, instanceValue));
//        System.out.println("After adding a instance");
//        System.out.println("--------------------------");
//        System.out.println(evalResultDataset);
//        System.out.println("--------------------------");
        saveDataSet(evalResultDataset, path);

    }

    public static void saveDataSet(Instances dataSet, String path) throws java.lang.Exception {
        CSVSaver csvSaver = new CSVSaver();
        csvSaver.setInstances(dataSet);
        csvSaver.setFile(new File(path + ".csv"));
        csvSaver.writeBatch();

        ArffSaver arffSaver = new ArffSaver();
        arffSaver.setInstances(dataSet);
        arffSaver.setFile(new File(path + ".arff"));
        arffSaver.writeBatch();
    }

    public static double round(double value, int places) {
        double scale = Math.pow(10, places);
        return Math.round(value * scale) / scale;
    }

    public static Boolean getOneMonthData(Instance instance, String baseDate) {   // format dd/mm/yy

        Boolean addInstance = true;
        String dateTime = instance.stringValue(17);
        String currentMonth = dateTime.substring(dateTime.indexOf("/") + 1, dateTime.indexOf("/") + 3);
        String baseMonth = baseDate.substring(baseDate.indexOf("/") + 1, baseDate.indexOf("/") + 3);
        if (currentMonth.equals(baseMonth))
            addInstance = true;
        else
            addInstance = false;

        return addInstance;

    }

    public static Boolean getOneYearData(Instance instance, String baseDate) {   // format dd/mm/yy

        Boolean addInstance = true;
        String dateTime = instance.stringValue(17);
        String currentYear = dateTime.substring(dateTime.lastIndexOf("/") + 1, dateTime.length());
        String baseYear = baseDate.substring(baseDate.lastIndexOf("/") + 1, baseDate.length());
        if (currentYear.equals(baseYear))
            addInstance = true;
        else
            addInstance = false;

        return addInstance;

    }

    public static Instances removeNonNumeric(Instances dataSet, String indecis) {
        Instances output = null;
        try {
            Remove remove = new Remove();
            remove.setAttributeIndices(indecis);
            remove.setInputFormat(dataSet);
            output = Filter.useFilter(dataSet, remove);
            return output;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return output;
    }


    public static Instances getDataByMoreMonths(Instances dataSet, int startIndex, Instances output, int monthsNum) {

        String dateToStartTest = null;
        int testInstancesCounter = 0;
        int testTimes = 0;
        boolean setDateToStart = false;
        try {

            for (int row = startIndex; row < dataSet.numInstances(); row++) {
                Instance instance = dataSet.instance(row);
                if (!setDateToStart) {
                    dateToStartTest = instance.stringValue(17);
//                    System.out.println("dateToStartTest :" + dateToStartTest);
                }

                if (testTimes != monthsNum) {
                    setDateToStart = true;
                    if (getOneMonthData(instance, dateToStartTest)) {
                        output.add(instance); // collect instances to use as updating Classifier
                        testInstancesCounter++;
                    } else {
                        testTimes++;
                        dateToStartTest = instance.stringValue(17);
                    }
                }

            }
            return output;


        } catch (Exception e) {
            e.printStackTrace();
        }
        return output;
    }

    public static void testByOneYear(Instances dataSet, int startIndex, Instances output, Instances evalResultDataset, Classifier classifier, String startYear, String savedFileName) throws Exception {

        Instances nextYearToTest = getOneYearDataFromStartIndex(dataSet, startIndex, output, startYear);
        nextYearToTest = PrepareClassAttributes(nextYearToTest, "1,2,3,4,5,6,7");
        String top = "PCut1"; // Threshold OPtion  PCut1 or PCutl
        String vop = "4";  //Specify more/less evaluation output
        Result result = Evaluation.evaluateModel((MultiXClassifier) classifier, removeNonNumeric(nextYearToTest, "18,19"), top, vop);
        System.out.println("Evaluation Info: " + result.toString());
        double longitudeVariance = nextYearToTest.variance(19);
        double latitudeVariance = nextYearToTest.variance(20);
        double altitudeVariance = nextYearToTest.variance(21);
        double longitudeMean = nextYearToTest.meanOrMode(19);
        double latitudeMean = nextYearToTest.meanOrMode(20);
        double altitudeMean = nextYearToTest.meanOrMode(21);
        saveEvaluationResult(evalResultDataset, startYear, round(((Double) result.getMeasurement("Hamming score")).doubleValue(), 4), nextYearToTest.numInstances(), savedFileName,longitudeVariance,latitudeVariance,altitudeVariance,longitudeMean,latitudeMean,altitudeMean);
        nextYearToTest.delete();
        output.delete();

    }

    public static Instances getOneYearDataFromStartIndex(Instances dataSet, int startIndex, Instances output, String startYear) {


        for (int row = startIndex; row < dataSet.numInstances(); row++) {
            Instance instance = dataSet.instance(row);
            if (getOneYearData(instance, startYear)) {
                output.add(instance);
            }
        }
        return output;
    }
    public static void testByMonths(Instances dataSet, int startIndex, Instances output, Instances evalResultDataset, Classifier classifier, String testDate, String savedFileName , int monthsNum) throws Exception {

        Instances threeMonthsData = getDataByMoreMonths(dataSet, startIndex, output, monthsNum);
        threeMonthsData = PrepareClassAttributes(threeMonthsData, "1,2,3,4,5,6,7");
        String top = "PCut1"; // Threshold OPtion  PCut1 or PCutl
        String vop = "5";  //Specify more/less evaluation output
        Result result = Evaluation.evaluateModel((MultiXClassifier) classifier, removeNonNumeric(threeMonthsData, "18,19"), top, vop);
        System.out.println("Evaluation Info: " + result.toString());
        double longitudeVariance = round(threeMonthsData.variance(19),4);
        double latitudeVariance = round(threeMonthsData.variance(20),4);
        double altitudeVariance = round(threeMonthsData.variance(21),4);
        double longitudeMean = round(threeMonthsData.meanOrMode(19),4);
        double latitudeMean = round(threeMonthsData.meanOrMode(20),4);
        double altitudeMean = round(threeMonthsData.meanOrMode(21),4);

        saveEvaluationResult(evalResultDataset, testDate, round(((Double) result.getMeasurement("Levenshtein distance")).doubleValue(), 4),
                            threeMonthsData.numInstances(), savedFileName , longitudeVariance, latitudeVariance, altitudeVariance,longitudeMean, latitudeMean, altitudeMean);
        threeMonthsData.delete();
        output.delete();

    }

    public static void extractedEuropeData(String originFilePath , String europeFilePath ) {
        try {
            ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(originFilePath); // Prepade dataset
            Instances preparedDataSet = dataSource.getDataSet();
            Instances europeDataset = new Instances(dataSource.getStructure());

            for (int row = 0; row < preparedDataSet.numInstances(); row++) {
                Instance instance = preparedDataSet.instance(row);
                double longitude = instance.value(19);
                double latitude = instance.value(20);
                if(isInEuropeAndNearby(latitude, longitude)){
                    europeDataset.add(instance);
                }
            }
            saveDataSet(europeDataset,europeFilePath);
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    /***
     *
     * This method checks if given lat,long is located in one of european counties.
     *
     * @param latitude
     * @param longitude
     * @return
     */
    public static boolean isInEurope(double latitude, double longitude) {
        String country = getCountryFromLatLong(latitude, longitude, false);
        String countryFull = getCountryFromLatLong(latitude, longitude, true);

        System.out.println(latitude+"\t"+longitude+"\t"+countryFull);
        return Arrays.asList(europeanCountries).contains(country);
    }

    public static boolean isInEuropeAndNearby(double latitude, double longitude) {
        String countryFull = getCountryFromLatLong(latitude, longitude, true);
        boolean europe= false;

        if( (latitude >= 10 && latitude <= 80) && (longitude >= 8 && longitude <= 40) ) {
//        if (latitude >= 18 && latitude <= 71) {
//            if (longitude >= 11 && longitude <= 33) {
                System.out.println(latitude + "\t" + longitude + "\t" + countryFull);
                europe = true;
            }
//        }
        return europe;
    }

    /***
     *
     * This method returns country fullname or shortname based on given lat,long and boolean value for fullName.
     * "International Waters" or "IWT" is used for places which are belong to all world and not to specific country.
     *
     * @param latitude
     * @param longitude        System.out.println(latitude+"\t"+longitude+"\t"+countryFull);

     * @param fullName
     * @return
     */
    public static String getCountryFromLatLong(double latitude, double longitude, boolean fullName) {
        String targetURL = "http://reverse.geocoder.api.here.com/6.2/reversegeocode.json?app_id=J3C1H9MEIuXoTqj1gbqd&app_code=5nYQ1Qek4nnAeqO_TyDZOw&mode=retrieveAll&prox="+latitude+","+longitude;
        String response = "";
        try {
            URL url = new URL(targetURL);
            URLConnection urlConnection = url.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response+=inputLine;
            }
            in.close();
        } catch (Exception e) {
            System.out.println("EXCEPTION");
        }
        String country;
        int start;
        if (fullName) {
            start = response.indexOf("\"AdditionalData\":[{\"value\":\"");
            country = "International Waters";
        } else {
            start = response.indexOf("\"Country\":\"");
            country = "IWT";
        }
        if (start!=-1) {
            int end = response.indexOf(",", start);
            country = response.substring(start, end).split("\":\"")[1].replaceAll("\"", "");
        }

        return country;
    }


    public static Instances createActualsPredictionsDataset() {


        ArrayList<Attribute> attr = new ArrayList<Attribute>();
        attr.add(new Attribute("actualEthane"));
        attr.add(new Attribute("actualNButane"));
        attr.add(new Attribute("actualNPentane"));
        attr.add(new Attribute("actualPropane"));
        attr.add(new Attribute("actualBenzene"));
        attr.add(new Attribute("actualIButane"));
        attr.add(new Attribute("actualIPentane"));

        attr.add(new Attribute("predictedEthane"));
        attr.add(new Attribute("predictedNButane"));
        attr.add(new Attribute("predictedNPentane"));
        attr.add(new Attribute("predictedPropane"));
        attr.add(new Attribute("predictedBenzene"));
        attr.add(new Attribute("predictedIButane"));
        attr.add(new Attribute("predictedIPentane"));
        Instances instances = new Instances("actualsPredictionsDataset", attr, 0);
        return instances;

    }

    public static void saveActualsPredictions(Instances actualsPredictionsDataset, String path, double actualEthane, double actualNButane, double actualNPentane, double actualPropane ,  double actualBenzene, double actualIButane, double actualIPentane,
                                                 double predictedEthane, double predictedNButane, double predictedNPentane, double predictedPropane ,  double predictedBenzene, double predictedIButane, double predictedIPentane) throws Exception {

        double[] instanceValue = new double[actualsPredictionsDataset.numAttributes()];

        instanceValue[0] = actualEthane;
        instanceValue[1] = actualNButane;
        instanceValue[2] = actualNPentane;
        instanceValue[3] = actualPropane;
        instanceValue[4] = actualBenzene;
        instanceValue[5] = actualIButane;
        instanceValue[6] = actualIPentane;
        instanceValue[7] = predictedEthane;
        instanceValue[8] = predictedNButane;
        instanceValue[9] = predictedNPentane;
        instanceValue[10] = predictedPropane;
        instanceValue[11] = predictedBenzene;
        instanceValue[12] = predictedIButane;
        instanceValue[13] = predictedIPentane;

        actualsPredictionsDataset.add(new DenseInstance(1.0, instanceValue));
//        System.out.println("After adding a instance");
//        System.out.println("--------------------------");
//        System.out.println(evalResultDataset);
//        System.out.println("--------------------------");
        saveDataSet(actualsPredictionsDataset, path);

    }


    public static double[][] mergeActualsAndPredictions(double[][] actuals, double[][] predictions) {

        double[][] all = new double[actuals.length][actuals[0].length + predictions[0].length];
        // print actual
//        System.out.println("*** Actuals ***");
        for (int h = 0; h < actuals.length; h++) {
//            System.out.println();
            for (int k = 0; k < actuals[h].length; k++) {
//                System.out.print( actuals[h][k]+"\t");
            }
        }
        // print predictions
//        System.out.println("*** Predictions ***");
        for (int h = 0; h < predictions.length; h++) {
//            System.out.println();
            for (int k = 0; k < predictions[h].length; k++) {
//                System.out.print(predictions[h][k]+"\t");
            }
        }
            // Merge
            for (int i = 0; i < actuals.length; i++) {
                for (int j = 0; j < actuals[0].length; j++) {
                    all[i][j] = actuals[i][j];
                }
                for (int j = 0; j < predictions[0].length; j++) {
                    all[i][actuals[0].length + j] = round(predictions[i][j],2);

                }
            }

            // print merged
            System.out.println("*** Merged ***");
            for (int i = 0; i < all.length; i++) {
                System.out.println();
                for (int j = 0; j < all[0].length; j++) {
                    System.out.print(all[i][j] + "\t");
                }
            }

            return all;
        }

    public static void writeActualPredictionsInCsvFile(BufferedWriter br, ArrayList<double[]> allActualsPredictions) throws Exception  {

        StringBuilder sb = new StringBuilder();
        sb.append("Actual Ethane,Actual N-Butane,Actual N-Pentane,Actual Propane,Actual Benzene,Actual I-Butane,Actual I-Pentane,Predicted Ethane,Predicted N-Butane,Predicted N-Pentane,Predicted Propane,Predicted Benzene,Predicted I-Butane,Predicted I-Pentane");
        sb.append(System.getProperty("line.separator"));
        for(int i=0;i<allActualsPredictions.size();i++){
            for(int j =0;j<allActualsPredictions.get(i).length;j++){
                sb.append(allActualsPredictions.get(i)[j]);
                sb.append(",");
            }
            sb.append(System.getProperty("line.separator"));

        }

        br.write(sb.toString());

    }
    public static RandomForest createRandomForest(int numberOfTrees , int depthOfTrees , int minVarianceForSplit) {
        RandomForest rf = new RandomForest();
        String[] rfOptions = new String[2];
//        rfOptions[0] = "-I";
//        rfOptions[1] = ""+numberOfTrees;
        rfOptions[0] = "-depth";
        rfOptions[1] = ""+depthOfTrees;
//        rfOptions[4] = "-V";
//        rfOptions[5] = ""+minVarianceForSplit;
        try {
            rf.setOptions(rfOptions);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rf;
    }
    public static boolean predictTargetColumn(Instances originalDataSet, Instances trainingData, int rowIndex , int trainingIndex, int targetColumnIndex, RandomForest randomForest ,Instances  predictedDataset) {
        // set target column for prediction
        Instance instance = originalDataSet.instance(rowIndex);
        boolean isTargetColumnAtCurrentRowMissing = instance.isMissing(targetColumnIndex);
        try {

            // same block //
            originalDataSet.setClassIndex(targetColumnIndex);
            trainingData.setClassIndex(targetColumnIndex);
            predictedDataset.setClassIndex(targetColumnIndex);
            randomForest.buildClassifier(trainingData); // move to out of this method, because the training model is not change any more here , then we can call it before this method, faster, if it is here calling build classifier per each target
            double predictedValue = round(randomForest.classifyInstance(instance),2);
            // end block //
//            if (isTargetColumnAtCurrentRowMissing) {  // set predicted value in both origin and training data sets
                instance.setValue(targetColumnIndex, predictedValue);
                originalDataSet.set(rowIndex, instance);
//            trainingData.set(rowIndex, instance);
            trainingData.set(trainingIndex, instance);
//            } // either missing or not put in this dataset just for evaluation.
            Instance tempInstance = (Instance)instance.copy();
            tempInstance.setValue(targetColumnIndex, predictedValue);
            predictedDataset.set(rowIndex,tempInstance);


        } catch (Exception e) {
            e.printStackTrace();
        }
        return isTargetColumnAtCurrentRowMissing;
    }
    public static Instances filterUnsupervisedAttributes(Instances dataSet) {
        try {
            RemoveType removeType = new RemoveType();
            removeType.setInputFormat(dataSet);
            return Filter.useFilter(dataSet, removeType);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void writeEach500EvalResult(BufferedWriter br, double[][] result) throws Exception  {

        StringBuilder sb = new StringBuilder();
        sb.append("Row,MAE,RMSE");
        sb.append(System.getProperty("line.separator"));
        for(int i=0;i<result.length;i++){
            for(int j =0;j<result[i].length;j++){
                sb.append(result[i][j]);
                sb.append(",");
            }
            sb.append(System.getProperty("line.separator"));

        }

        br.write(sb.toString());

    }
    public static void writeAdwinResult(BufferedWriter br, ArrayList<int[]> result) throws Exception  {

        StringBuilder sb = new StringBuilder();
        sb.append("Ethane,N-Butane,N-Pentane,Propane,Benzene,I-Butane,I-Pentane");
        sb.append(System.getProperty("line.separator"));


        for(int i=0;i<result.size();i++){

            for(int j =0;j<result.get(i).length;j++){
                sb.append(result.get(i)[j]);
                sb.append(System.getProperty("line.separator"));
                if(i>0) sb.append(",");

            }
//            sb.append("\t");
            sb.append(",");


        }

        br.write(sb.toString());


    }

    public static void writeAdwinResult2(BufferedWriter br, ArrayList<boolean[]> result) throws Exception  {

        StringBuilder sb = new StringBuilder();
        sb.append("Ethane,N-Butane,N-Pentane,Propane,Benzene,I-Butane,I-Pentane");
        sb.append(System.getProperty("line.separator"));


        for(int i=0;i<result.size();i++){

            for(int j =0;j<result.get(i).length;j++){
                sb.append(result.get(i)[j]);
                sb.append(System.getProperty("line.separator"));

            }
//            sb.append("\t");
            sb.append(",");


        }

        br.write(sb.toString());


    }

    public static void writeEach500Visualization(BufferedWriter br, M5P m5pClassifier , int targetIndex , int row) throws Exception  {

        StringBuilder sb = new StringBuilder();
        sb.append("at row : "+row +" Target index : "+targetIndex);
        sb.append(System.getProperty("line.separator"));
        sb.append(m5pClassifier.toString());

        br.write(sb.toString());

    }

    public static Instances keepLast500Instances(Instances instances) throws Exception {
        int numInstances = instances.numInstances();

        for (int i = 0; i < numInstances; i++) {
            if(i<numInstances - 100){
                instances.delete(0);
            }
        }
        return instances;
    }

    /**
     * This method predict the targets by Decision tree.
     * @param originalDataSet
     * @param trainingData
     * @param rowIndex
     * @param trainingIndex
     * @param targetColumnIndex
     * @param m5pClassifier
     * @param predictedDataset
     * @return
     */
    public static boolean predictTargetColumnsByDT(Instances originalDataSet, Instances trainingData, int rowIndex , int trainingIndex, int targetColumnIndex, M5P m5pClassifier,Instances  predictedDataset) {
        // set target column for prediction
        Instance instance = originalDataSet.instance(rowIndex);
        boolean isTargetColumnAtCurrentRowMissing = instance.isMissing(targetColumnIndex);
        try {


            // same block //
            originalDataSet.setClassIndex(targetColumnIndex);
            trainingData.setClassIndex(targetColumnIndex);
            predictedDataset.setClassIndex(targetColumnIndex);

            Instance tempInstance = (Instance)instance.copy();

            m5pClassifier.buildClassifier(trainingData);

            //////////// visualize M5P tree//////////////

////            if(rowIndex>0 && rowIndex % 500 == 0){
////                BufferedWriter br4Visualization = new BufferedWriter(new FileWriter("/Users/ali/Desktop/COMPSCI791A/"+targetColumnIndex+"TargetVisualization"+rowIndex+"row.txt"));
////
//////                System.out.println("targetIndex : "+targetColumnIndex+"......"+m5pClassifier);
////                final javax.swing.JFrame jf = new javax.swing.JFrame("Weka Classifier Tree Visualizer: M5P" + "row : "+rowIndex+" at targetIndex :"+targetColumnIndex);
////                jf.setSize(1100,800);
////                jf.getContentPane().setLayout(new BorderLayout());
////                TreeVisualizer tv = new TreeVisualizer(null, m5pClassifier.graph(), new PlaceNode2());
////
////                jf.getContentPane().add(tv, BorderLayout.CENTER);
////                jf.addWindowListener(new java.awt.event.WindowAdapter() {
////                    public void windowClosing(java.awt.event.WindowEvent e) {
////                        jf.dispose();
////                    }
////                });
////
////                jf.setVisible(true);
////                tv.fitToScreen();
////
////                BufferedImage image = new BufferedImage(jf.getWidth(), jf.getHeight(), BufferedImage.TYPE_INT_RGB);
////                Graphics2D graphics2D = image.createGraphics();
////                jf.paint(graphics2D);
////                ImageIO.write(image,"jpeg", new File("/Users/ali/Desktop/COMPSCI791A/TreeAtRow"+rowIndex+"Target"+targetColumnIndex+".jpeg"));
//
//
//
//                writeEach500Visualization(br4Visualization,m5pClassifier,targetColumnIndex,rowIndex);
//                br4Visualization.close();
//
//            }

            //////////// visualize M5P tree//////////////

            double predictedValue = m5pClassifier.classifyInstance(instance);

            instance.setValue(targetColumnIndex, round(predictedValue,2));
            tempInstance.setValue(targetColumnIndex, round(predictedValue,2));

//            originalDataSet.set(rowIndex, instance);


            trainingData.set(trainingIndex, instance);
            predictedDataset.set(rowIndex,tempInstance);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return isTargetColumnAtCurrentRowMissing;
    }

    /**
     * This method predict the targets by hoeffdingTree.
     * @param originalDataSet
     * @param trainingData
     * @param rowIndex
     * @param trainingIndex
     * @param targetColumnIndex
     * @param hoeffdingTree
     * @param predictedDataset
     * @return
     */
    public static boolean predictTargetColumnsByHT(Instances originalDataSet, Instances trainingData, int rowIndex , int trainingIndex, int targetColumnIndex, HoeffdingTree hoeffdingTree,Instances  predictedDataset) {
        // set target column for prediction
        Instance instance = originalDataSet.instance(rowIndex);
        boolean isTargetColumnAtCurrentRowMissing = instance.isMissing(targetColumnIndex);
        try {


            // same block //
            originalDataSet.setClassIndex(targetColumnIndex);
            trainingData.setClassIndex(targetColumnIndex);
            predictedDataset.setClassIndex(targetColumnIndex);

            Instance tempInstance = (Instance)instance.copy();

            hoeffdingTree.buildClassifier(trainingData);

            //////////// visualize M5P tree//////////////

            if(rowIndex>0 && rowIndex % 500 == 0){
//                BufferedWriter br4Visualization = new BufferedWriter(new FileWriter("/Users/ali/Desktop/COMPSCI791A/"+targetColumnIndex+"TargetVisualization"+rowIndex+"row.txt"));

//                System.out.println("targetIndex : "+targetColumnIndex+"......"+m5pClassifier);
                final javax.swing.JFrame jf = new javax.swing.JFrame("Weka Classifier Tree Visualizer: M5P" + "row : "+rowIndex+" at targetIndex :"+targetColumnIndex);
                jf.setSize(500,400);
                jf.getContentPane().setLayout(new BorderLayout());
                TreeVisualizer tv = new TreeVisualizer(null, hoeffdingTree.graph(), new PlaceNode2());

                jf.getContentPane().add(tv, BorderLayout.CENTER);
                jf.addWindowListener(new java.awt.event.WindowAdapter() {
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        jf.dispose();
                    }
                });

                jf.setVisible(true);
                tv.fitToScreen();
//                writeEach500Visualization(br4Visualization,hoeffdingTree,targetColumnIndex,rowIndex);
//                br4Visualization.close();

            }

            //////////// visualize M5P tree//////////////

            double predictedValue = hoeffdingTree.classifyInstance(instance);

            instance.setValue(targetColumnIndex, round(predictedValue,2));
            tempInstance.setValue(targetColumnIndex, round(predictedValue,2));

            originalDataSet.set(rowIndex, instance);


            trainingData.set(trainingIndex, instance);
            predictedDataset.set(rowIndex,tempInstance);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return isTargetColumnAtCurrentRowMissing;
    }

    public static void writeAdwinEpsilonAbsvalue(BufferedWriter br, double[][] result) throws Exception  {

        StringBuilder sb = new StringBuilder();
        sb.append("change");
        sb.append(System.getProperty("line.separator"));
        for(int i=0;i<result.length;i++){
            for(int j =0;j<result[i].length;j++){
                sb.append(result[i][j]);
                sb.append(",");
            }
            sb.append(System.getProperty("line.separator"));

        }

        br.write(sb.toString());

    }


    /**
     * Predict targets and detect change by Adwin, if there is any change, visualize the tree
     * @param path
     * @throws java.lang.Exception
     */
    public static void predictByM5PPerAdwinDetectionPoint(String path) throws java.lang.Exception {
//        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(PREPARED_DATA_2009_TO_2012);
        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(PREPARED_DATA_NODATE_2009_2012);

        Instances originalDataSet = dataSource.getDataSet();
        Instances trainingData = new Instances(dataSource.getStructure());
        Instances predictedDataset = dataSource.getDataSet();
        originalDataSet = filterUnsupervisedAttributes(originalDataSet);
        predictedDataset = filterUnsupervisedAttributes(predictedDataset);
        trainingData = filterUnsupervisedAttributes(trainingData);

        M5P  m5pClassifier= new M5P();
        ADWIN adwin = new ADWIN();

        int numInst = originalDataSet.numInstances();
        int trainingIndex = 0;
        int changePoint = 0;

        for (int row = 0; row < numInst; row++) {
            long start = System.currentTimeMillis();
            int numMissingValues = 1;
            // get first bunch of data as 200 rows
            // for the next bunch of data Adwin decide
            Instance mainInstance = (Instance) originalDataSet.instance(row);
            trainingData.add(mainInstance);
            trainingIndex = trainingData.size()-1;
            if(row >= 200){

                changePoint = predictTargetsAndVisualizeByAdwin(originalDataSet, trainingData, row , trainingIndex, 3, changePoint,m5pClassifier,adwin ,predictedDataset);


            }

            long end = System.currentTimeMillis();
            System.out.println("Row #" + row + " is processed in " + (end - start) + " milllis with " + numMissingValues + " calculated missing values.");
            System.out.println("Original:\t" +
                    mainInstance.value(0) + ",\t" +
                    mainInstance.value(1) + ",\t" +
                    mainInstance.value(2) + ",\t" +
                    mainInstance.value(3) + ",\t" +
                    mainInstance.value(4) + ",\t" +
                    mainInstance.value(5) + ",\t" +
                    mainInstance.value(6) + ",\t"
            );

            Instance allPredictedInstance = predictedDataset.instance(row);
            System.out.println("Predicted:\t" +
                    allPredictedInstance.value(0) + ",\t" +
                    allPredictedInstance.value(1) + ",\t" +
                    allPredictedInstance.value(2) + ",\t" +
                    allPredictedInstance.value(3) + ",\t" +
                    allPredictedInstance.value(4) + ",\t" +
                    allPredictedInstance.value(5) + ",\t" +
                    allPredictedInstance.value(6) + ",\t"
            );
            System.out.println("--------------------------------------------------------------------------");
        }



    }

    /**
     *  this method calling by "predictByM5PPerAdwinDetectionPoint" and do the same process.
     * @param originalDataSet
     * @param trainingData
     * @param rowIndex
     * @param trainingIndex
     * @param targetColumnIndex
     * @param changePoint
     * @param m5pClassifier
     * @param adwin
     * @param predictedDataset
     * @return
     */

    public static int predictTargetsAndVisualizeByAdwin(Instances originalDataSet, Instances trainingData, int rowIndex , int trainingIndex, int targetColumnIndex, int changePoint ,M5P m5pClassifier,ADWIN adwin,Instances  predictedDataset) {
        // set target column for prediction
        Instance instance = originalDataSet.instance(rowIndex);
        boolean isTargetColumnAtCurrentRowMissing = instance.isMissing(targetColumnIndex);
        try {

            originalDataSet.setClassIndex(targetColumnIndex);
            trainingData.setClassIndex(targetColumnIndex);
            predictedDataset.setClassIndex(targetColumnIndex);

            Instance tempInstance = (Instance)instance.copy();

            m5pClassifier.buildClassifier(trainingData);
            double predictedValue = m5pClassifier.classifyInstance(instance);


            double ressidual = predictedValue - instance.value(targetColumnIndex) ;

            adwin.setInput(ressidual);
            System.out.println("ressidual ==> "+ressidual +" Adwing Change :"+adwin.getChange());

            if(rowIndex == 200 ){
                visualizeTree(m5pClassifier , targetColumnIndex , rowIndex);
                changePoint = 200;
            }
            if(rowIndex != 200  && adwin.getChange() ){
                System.out.println("change detection at rowIndex and trainingindex : "+rowIndex+" and "+trainingIndex);
                visualizeTree(m5pClassifier , targetColumnIndex , rowIndex);
                trainingData = keepLastBuchOfInstances(trainingData, changePoint);
                m5pClassifier = new M5P();
                m5pClassifier.buildClassifier(trainingData);
                changePoint = trainingData.size();



            }
            tempInstance.setValue(targetColumnIndex, round(predictedValue,2));
            trainingData.set(trainingData.size() - 1, tempInstance);
            predictedDataset.set(rowIndex,tempInstance);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return changePoint;
    }

    /**
     * this method is using to visualize the trees.
     * @param classifier
     * @param targetColumnIndex
     * @param rowIndex
     */
    public static void visualizeTree(M5P classifier , int targetColumnIndex , int rowIndex) {
        try {
        String targetName="";
        if (targetColumnIndex == 0)
            targetName = "Ethane";
        else if (targetColumnIndex == 1)
            targetName = "NButane";
        else if (targetColumnIndex == 2)
            targetName = "NPentane";
        else if (targetColumnIndex == 3)
            targetName = "Propane";
        else if (targetColumnIndex == 4)
            targetName = "Benzene";
        else if (targetColumnIndex == 5)
            targetName = "IButane";
        else if (targetColumnIndex == 6)
            targetName = "IPentane";

                BufferedWriter br4Visualization = new BufferedWriter(new FileWriter("/Users/ali/Desktop/COMPSCI791A/"+targetName+"AtRow"+rowIndex+".txt"));

//                System.out.println("targetIndex : "+targetColumnIndex+"......"+m5pClassifier);
        final javax.swing.JFrame jf = new javax.swing.JFrame("Tree Visualizer at " + "row : "+rowIndex+" for target :"+targetName);
        jf.setSize(1600,1000);
        jf.getContentPane().setLayout(new BorderLayout());
        TreeVisualizer tv = new TreeVisualizer(null, classifier.graph(), new PlaceNode2());

        jf.getContentPane().add(tv, BorderLayout.CENTER);
        jf.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent e) {
                jf.dispose();
            }
        });

        jf.setVisible(true);
        tv.fitToScreen();

        BufferedImage image = new BufferedImage(jf.getWidth(), jf.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics2D = image.createGraphics();
        jf.paint(graphics2D);
        ImageIO.write(image,"jpeg", new File("/Users/ali/Desktop/COMPSCI791A/"+targetName+"AtRow"+rowIndex+".jpeg"));



        writeEach500Visualization(br4Visualization,classifier,targetColumnIndex,rowIndex);
        br4Visualization.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public static Instances keepLastBuchOfInstances(Instances instances , int changePoint) throws Exception {
        int numInstances = instances.numInstances();

        for (int i = 0; i < numInstances; i++) {
            if(i< changePoint){
                instances.delete(0);
            }
        }
        return instances;
    }
    /////////////////////////////////// 5 April///////////////////////////////
    // train model by M5P and whole ds(withou date,time,flight and sample just to visualize tree)
    public static void trainByWholeDataset() throws java.lang.Exception{
        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(FILE_PATH);
        Instances originalDataSet = dataSource.getDataSet();
        M5P  m5pClassifier= new M5P();
        int[] indices = new int[]{0,1,9,10};
        Remove removeFilter = new Remove();
        removeFilter.setAttributeIndicesArray(indices);
        removeFilter.setInputFormat(originalDataSet);
        Instances dataAfterRemove4Atts = Filter.useFilter(originalDataSet, removeFilter);
//        Attribute checkAtt = dataAfterRemove4Atts.get(0).attribute(37);
        dataAfterRemove4Atts.setClassIndex(41); // 36 :Ethane , 40: NButane , 42:NPentane , 37:Propane , 46:benzene , 39:IButane , 41:IPentane
        m5pClassifier.buildClassifier(dataAfterRemove4Atts);
        visualizeTree(m5pClassifier , 6 , 0);
    }



    /////////////////////////////////// 12 April///////////////////////////////
    // 1. Training model  by M5P and dataset(whole ds WITHOUT date,time,flight and sample) return tree visualization and RMSE_MAE)
    // 2. Training model  by M5P and dataset(whole ds WITHOUT flight and sample , DATE SHOULD BE IN(YEAR,MONTH,DAY) AND TIME IN SECONDS) return tree visualization and RMSE_MAE)

    /**
     * this method predicts the targets by M5P classifier and using prepared dataset(data set without 4 atts) and training by each 100 instances.
     * @param path
     * @throws java.lang.Exception
     */
    public static void evaluateOriginalDatasetByM5P(String path ) throws java.lang.Exception {
        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(DATASETREMOVED4ATTS);
//        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(DATASET_CONVERTED_DATE_TIME_NOFLIGHT_NOSAMPLE);
        Instances originalDataSet = dataSource.getDataSet();

        Instances trainingData = new Instances(dataSource.getStructure());

        Instances predictedDataset = dataSource.getDataSet();


        originalDataSet = filterUnsupervisedAttributes(originalDataSet);
        predictedDataset = filterUnsupervisedAttributes(predictedDataset);
        trainingData = filterUnsupervisedAttributes(trainingData);



        M5P m5pClassifier = new M5P();
        BufferedWriter br = new BufferedWriter(new FileWriter(EACH_500_EVALUATION_FILE_PATH));
        double[][] temporarySpaceToWrite = new double[100][3] ;
        ArrayList<double[]> realPredictedValues = new ArrayList<double[]>() ;
        int numInst = originalDataSet.numInstances();
        int i = 0;
        int trainingIndex = 0;
        ADWIN adwin = new ADWIN();

        for (int row = 0; row <= 7400; row++) {
            long start = System.currentTimeMillis();
            int numMissingValues = 0;
            // save predicted values every 500 rows to use as training instances for the next 500 inatances.
            if (row > 0 && row % 100 == 0) {
                trainingData = keepLast500Instances(trainingData);
                weka.classifiers.Evaluation eval = new weka.classifiers.Evaluation(trainingData);
                eval.evaluateModel(m5pClassifier, predictedDataset);
//                System.out.println(eval.toSummaryString("\nResults\n========================================\n", true));
                temporarySpaceToWrite[i][0]=row;
                temporarySpaceToWrite[i][1]=round(eval.meanAbsoluteError(),2);
                temporarySpaceToWrite[i][2]=round(eval.rootMeanSquaredError(),2);
                i++;

                m5pClassifier = new M5P();
                // change to create 500 training data blocks
                saveDataSet(trainingData, "/Users/ali/Desktop/COMPSCI791A/Predicted_First_" + row + "_rows");
            }
            trainingIndex = trainingData.size();

            Instance originInstance = (Instance) originalDataSet.instance(row).copy();
            trainingData.add(originInstance);

            if (predictTargetColumnM5P(originalDataSet, trainingData, row , trainingIndex, 6, m5pClassifier, predictedDataset ,adwin,m5pClassifier))
                numMissingValues++;
//            if (predictTargetColumnM5P(originalDataSet, trainingData, row , trainingIndex, 1, m5pClassifier, predictedDataset,adwin,m5pClassifier))
//                numMissingValues++;
//            if (predictTargetColumnM5P(originalDataSet, trainingData, row , trainingIndex, 2, m5pClassifier, predictedDataset,adwin,m5pClassifier))
//                numMissingValues++;
//            if (predictTargetColumnM5P(originalDataSet, trainingData, row , trainingIndex, 3, m5pClassifier, predictedDataset,adwin,m5pClassifier))
//                numMissingValues++;
//            if (predictTargetColumnM5P(originalDataSet, trainingData, row , trainingIndex, 4, m5pClassifier, predictedDataset,adwin,m5pClassifier))
//                numMissingValues++;
//            if (predictTargetColumnM5P(originalDataSet, trainingData, row , trainingIndex, 5, m5pClassifier, predictedDataset,adwin,m5pClassifier))
//                numMissingValues++;
//            if (predictTargetColumnM5P(originalDataSet, trainingData, row , trainingIndex, 6, m5pClassifier, predictedDataset,adwin,m5pClassifier))
//                numMissingValues++;
            trainingIndex++;




            long end = System.currentTimeMillis();
//            System.out.println("Row #" + row + " is processed in " + (end - start) + " milllis with " + numMissingValues + " calculated missing values.");
//            System.out.println("Original:\t" +
//                    originInstance.value(0) + ",\t" +
//                    originInstance.value(1) + ",\t" +
//                    originInstance.value(2) + ",\t" +
//                    originInstance.value(3) + ",\t" +
//                    originInstance.value(4) + ",\t" +
//                    originInstance.value(5) + ",\t" +
//                    originInstance.value(6) + ",\t"
//            );

            Instance allPredictedInstance = predictedDataset.instance(row);
//            System.out.println("Predicted:\t" +
//                    allPredictedInstance.value(0) + ",\t" +
//                    allPredictedInstance.value(1) + ",\t" +
//                    allPredictedInstance.value(2) + ",\t" +
//                    allPredictedInstance.value(3) + ",\t" +
//                    allPredictedInstance.value(4) + ",\t" +
//                    allPredictedInstance.value(5) + ",\t" +
//                    allPredictedInstance.value(6) + ",\t"
//            );
//            System.out.println("--------------------------------------------------------------------------");
        }
        saveDataSet(predictedDataset, "/Users/ali/Desktop/COMPSCI791A/ALLPredicted");

        writeEach500EvalResult( br, temporarySpaceToWrite);
        br.close();



    }


    public static boolean predictTargetColumnM5P(Instances originalDataSet, Instances trainingData, int rowIndex , int trainingIndex, int targetColumnIndex, M5P m5p ,Instances  predictedDataset,ADWIN adwin,M5P m5pClassifier ) {
        // set target column for prediction
        Instance instance = originalDataSet.instance(rowIndex);
        boolean isTargetColumnAtCurrentRowMissing = instance.isMissing(targetColumnIndex);
        try {

            // same block //
            originalDataSet.setClassIndex(targetColumnIndex);
            trainingData.setClassIndex(targetColumnIndex);
            predictedDataset.setClassIndex(targetColumnIndex);
            m5p.buildClassifier(trainingData); // move to out of this method, because the training model is not change any more here , then we can call it before this method, faster, if it is here calling build classifier per each target
            double predictedValue = round(m5p.classifyInstance(instance),2);

            double ressidual = predictedValue - instance.value(targetColumnIndex) ;
            adwin.setInput(ressidual,0.00001);
//            if(adwin.getChange()){
//                visualizeTree(m5pClassifier , targetColumnIndex , rowIndex);
//            }
            if(adwin.getChange()){
                System.out.println("Changed point at this index: "+rowIndex + " for this target : "+targetColumnIndex);
//                reliefAttributeEval(predictedDataset);
                pcaAttributeEval(predictedDataset);
            }
            // end block //
//            if (isTargetColumnAtCurrentRowMissing) {  // set predicted value in both origin and training data sets
            instance.setValue(targetColumnIndex, predictedValue);
            originalDataSet.set(rowIndex, instance);
//            trainingData.set(rowIndex, instance);
            trainingData.set(trainingIndex, instance);
//            } // either missing or not put in this dataset just for evaluation.
            Instance tempInstance = (Instance)instance.copy();
            tempInstance.setValue(targetColumnIndex, predictedValue);
            predictedDataset.set(rowIndex,tempInstance);


        } catch (Exception e) {
            e.printStackTrace();
        }
        return isTargetColumnAtCurrentRowMissing;
    }


    public static void rankingAttributes() throws java.lang.Exception {
        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(DATASETREMOVED4ATTS);
        Instances data = dataSource.getDataSet();
        reliefAttributeEval(data);
    }

    protected static void reliefAttributeEval(Instances data) throws Exception {
        System.out.println("\n Ranked Attributes");
        AttributeSelection attselection = new AttributeSelection();
        Ranker search = new Ranker();
        ReliefFAttributeEval evals = new ReliefFAttributeEval();
        attselection.setRanking(true);
        attselection.setEvaluator(evals);
        attselection.setSearch(search);
        attselection.SelectAttributes(data);




        // un-comment here to display the results from the ranking
//        System.out.println("attribute selection result");

        System.out.println(attselection.toResultsString());


//         expand the ranked attributes so you can find the index, name and weight of the features
//        double[][] ranked = attselection.rankedAttributes();
//        System.out.println("ranked attributes!!!\n");
//        for(int i=0;i<ranked.length;i++){
//            System.out.println(" Feature:"+ data.attribute(i).name() +" weight:"+ ranked[i][1]);
//        }




    }

    public static void pcaAttributeEval(Instances data) throws Exception {

        AttributeSelection attsel = new AttributeSelection(); // create and initiate a new AttributeSelection instance
        Ranker search = new Ranker(); // choose a search method
        PrincipalComponents pcaEval = new PrincipalComponents(); // choose an evaluation method
        pcaEval.setMaximumAttributeNames(10);
        attsel.setRanking(true);
        attsel.setEvaluator(pcaEval); // set evaluation method
        attsel.setSearch(search); // set search method
        attsel.SelectAttributes(data); // set the data to be used for attribute selection
        String rankedAttributes = attsel.toResultsString().substring(attsel.toResultsString().indexOf("Ranked attributes:"),attsel.toResultsString().length());
        System.out.println(rankedAttributes);
        double[][] selectedAtts = attsel.rankedAttributes();
//        System.out.println("**** "+selectedAtts[0][0]);
//        for(int i=0;i<selectedAtts.length;i++){
//            for(int j=0;j<selectedAtts[i].length;j++){
//                System.out.println(selectedAtts[i][j]);
//            }
//        }

//
    }

    /**
     * this method predicts targets in 1 step by M5P classifier using the dataset which converted date and time and also skip Flight and sample columns.
     * @throws java.lang.Exception
     */
    public static void trainByWholeDatasetIn1Step() throws java.lang.Exception {
//        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(DATASETREMOVED4ATTS);
        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(DATASET_CONVERTED_DATE_TIME_NOFLIGHT_NOSAMPLE);
        Instances originalDataSet = dataSource.getDataSet();
        Instances predictedDataset = dataSource.getDataSet();


        originalDataSet = filterUnsupervisedAttributes(originalDataSet);
        predictedDataset = filterUnsupervisedAttributes(predictedDataset);
        M5P m5pClassifier = new M5P();
        for(int i=0;i<7;i++){
            originalDataSet.setClassIndex(i);
            m5pClassifier.buildClassifier(originalDataSet);
            visualizeTree(m5pClassifier , i , 7400);
            for (int row = 0; row <= 7400; row++) {
                long start = System.currentTimeMillis();
                int numMissingValues = 0;

                Instance originInstance = (Instance) originalDataSet.instance(row).copy();

                if (predictByM5P1Step(originalDataSet, row, i , m5pClassifier, predictedDataset, m5pClassifier))
                    numMissingValues++;

                long end = System.currentTimeMillis();
                System.out.println("Row #" + row + " is processed in " + (end - start) + " milllis with " + numMissingValues + " calculated missing values.");
                System.out.println("Original:\t" +
                        originInstance.value(0) + ",\t" +
                        originInstance.value(1) + ",\t" +
                        originInstance.value(2) + ",\t" +
                        originInstance.value(3) + ",\t" +
                        originInstance.value(4) + ",\t" +
                        originInstance.value(5) + ",\t" +
                        originInstance.value(6) + ",\t"
                );

                Instance allPredictedInstance = predictedDataset.instance(row);
                System.out.println("Predicted:\t" +
                        allPredictedInstance.value(0) + ",\t" +
                        allPredictedInstance.value(1) + ",\t" +
                        allPredictedInstance.value(2) + ",\t" +
                        allPredictedInstance.value(3) + ",\t" +
                        allPredictedInstance.value(4) + ",\t" +
                        allPredictedInstance.value(5) + ",\t" +
                        allPredictedInstance.value(6) + ",\t"
                );
                System.out.println("--------------------------------------------------------------------------");
            }


            saveDataSet(predictedDataset, "/Users/ali/Desktop/COMPSCI791A/ALLPredicted"+i+" Target");


            weka.classifiers.Evaluation eval = new weka.classifiers.Evaluation(originalDataSet);
            eval.evaluateModel(m5pClassifier, predictedDataset);
            System.out.println(i+" Target "+"MEAN : "+round(eval.meanAbsoluteError(), 2));
            System.out.println(i+" Target "+"RMSE : "+round(eval.rootMeanSquaredError(), 2));
        }





    }
    public static boolean predictByM5P1Step(Instances originalDataSet, int rowIndex , int targetColumnIndex, M5P m5p ,Instances  predictedDataset,M5P m5pClassifier ) {
        Instance instance = originalDataSet.instance(rowIndex);
        boolean isTargetColumnAtCurrentRowMissing = instance.isMissing(targetColumnIndex);
        try {

            predictedDataset.setClassIndex(targetColumnIndex);
            double predictedValue = round(m5p.classifyInstance(instance),2);
            instance.setValue(targetColumnIndex, predictedValue);
            Instance tempInstance = (Instance)instance.copy();
            tempInstance.setValue(targetColumnIndex, predictedValue);
            predictedDataset.set(rowIndex,tempInstance);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isTargetColumnAtCurrentRowMissing;
    }


    /**
     * this method predict target one by one not all targets altogether.
     * @throws java.lang.Exception
     */

    public static void predictBySelectedAttributes() throws java.lang.Exception {
        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(DATASET_SELECTED_ATTRIBUTES);
        Instances originalDataSet = dataSource.getDataSet();
        Instances predictedDataset = dataSource.getDataSet();

        originalDataSet = filterUnsupervisedAttributes(originalDataSet);
        predictedDataset = filterUnsupervisedAttributes(predictedDataset);

        // we need remove targets from our list of predictors
        String indecies = "1,2,3,4";
        Remove remove = new Remove();
        remove.setAttributeIndices(indecies);
        remove.setInputFormat(originalDataSet);
        Instances trainingData = Filter.useFilter(originalDataSet, remove);



        for(int i=0;i<1;i++){
            M5P m5pClassifier = new M5P();
            m5pClassifier.setUnpruned(true);
            m5pClassifier.setBuildRegressionTree(true);
            trainingData.setClassIndex(0);
            m5pClassifier.buildClassifier(trainingData);
            visualizeTree(m5pClassifier , i , 7400);
            for (int row = 0; row <= 7400; row++) {
                long start = System.currentTimeMillis();
                int numMissingValues = 0;

                Instance originInstance = (Instance) originalDataSet.instance(row).copy();

                if (predictByM5P1Step(originalDataSet, row, i , m5pClassifier, predictedDataset, m5pClassifier))
                    numMissingValues++;

                long end = System.currentTimeMillis();
                System.out.println("Row #" + row + " is processed in " + (end - start) + " milllis with " + numMissingValues + " calculated missing values.");
                System.out.println("Original:\t" +
                        originInstance.value(0) + ",\t" +
                        originInstance.value(1) + ",\t" +
                        originInstance.value(2) + ",\t" +
                        originInstance.value(3) + ",\t" +
                        originInstance.value(4) + ",\t" +
                        originInstance.value(5) + ",\t" +
                        originInstance.value(6) + ",\t"
                );

                Instance allPredictedInstance = predictedDataset.instance(row);
                System.out.println("Predicted:\t" +
                        allPredictedInstance.value(0) + ",\t" +
                        allPredictedInstance.value(1) + ",\t" +
                        allPredictedInstance.value(2) + ",\t" +
                        allPredictedInstance.value(3) + ",\t" +
                        allPredictedInstance.value(4) + ",\t" +
                        allPredictedInstance.value(5) + ",\t" +
                        allPredictedInstance.value(6) + ",\t"
                );
                System.out.println("--------------------------------------------------------------------------");
            }



        }


        saveDataSet(predictedDataset, "/Users/ali/Desktop/COMPSCI791A/ALLPredictedTargets");



    }
}




