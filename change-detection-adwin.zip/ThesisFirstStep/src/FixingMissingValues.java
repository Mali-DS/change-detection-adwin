import weka.classifiers.Evaluation;
import weka.classifiers.trees.RandomForest;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVSaver;
import weka.core.converters.ConverterUtils;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.RemoveType;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class FixingMissingValues {
    public static final String RAW_DATA= "/Users/ali/Desktop/COMPSCI791A/WAS_Merge_110-536_20180112_TS_EDITED_Preparation.arff";
    public static final String EACH_500_EVALUATION_FILE_PATH = "/Users/ali/Desktop/COMPSCI791A/Each500EvaluationResult.csv";

    public static final int NUMBER_OF_TREES = 200;
    public static final int DEPTH_OF_TREES = 4;
    public static final int MIN_VARIANCE_FOR_SPLIT =100;


    public static final boolean EVALUATE = true;
    public static void main(String[] args) throws java.lang.Exception {
        String fileName= "/Users/ali/Desktop/COMPSCI791A/WAS_Merge_110-536_20180112_TS_EDITED_Preparation.arff";
        try {
            Instances fixedDataSet = fixMissingValues(fileName);
            saveDataSet(fixedDataSet, "/Users/ali/Desktop/COMPSCI791A/Missing_values_Predicted");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Instances fixMissingValues(String fileName) throws java.lang.Exception {

        DataSource dataSource = new DataSource(fileName);
        Instances dataSet = dataSource.getDataSet();

        Instances  trainingData = new Instances(dataSource.getStructure());
        Instances  predictedDataset = dataSource.getDataSet();
        dataSet = filterUnsupervisedAttributes(dataSet);
        predictedDataset = filterUnsupervisedAttributes(predictedDataset);
        trainingData = filterUnsupervisedAttributes(trainingData);
        RandomForest randomForest = createRandomForest(NUMBER_OF_TREES,DEPTH_OF_TREES,MIN_VARIANCE_FOR_SPLIT);

        int numInst = dataSet.numInstances();
        for(int row = 0; row < numInst; row++) {
            long start = System.currentTimeMillis();
            int numMissingValues = 0;
            // save predicted values every 100 rows ro avoid the lost in case of crash.

                if (row%500==0) {
                    saveDataSet(trainingData, "/Users/ali/Desktop/COMPSCI791A/Missing_values_Predicted_First_"+row+"_rows");
                }

                Instance originInstance = (Instance) dataSet.instance(row).copy();
                trainingData.add(originInstance);

                if (predictTargetColumn(dataSet, trainingData, row, 40, randomForest,predictedDataset)) numMissingValues++;
                if (predictTargetColumn(dataSet, trainingData, row, 41, randomForest,predictedDataset)) numMissingValues++;
                if (predictTargetColumn(dataSet, trainingData, row, 44, randomForest,predictedDataset)) numMissingValues++;
                if (predictTargetColumn(dataSet, trainingData, row, 46, randomForest,predictedDataset)) numMissingValues++;
                if (predictTargetColumn(dataSet, trainingData, row, 50, randomForest,predictedDataset)) numMissingValues++;

                if(row>5022) {
                    if (predictTargetColumn(dataSet, trainingData, row, 39, randomForest,predictedDataset)) numMissingValues++;
                }
                if(row>130) {
                    if (predictTargetColumn(dataSet, trainingData, row, 43, randomForest,predictedDataset)) numMissingValues++;
                }
                if(row>57) {
                    if (predictTargetColumn(dataSet, trainingData, row, 45, randomForest,predictedDataset)) numMissingValues++;
                }


                long end = System.currentTimeMillis();
                System.out.println("Row #" + row + " is processed in "+ (end - start) + " milllis with " + numMissingValues + " calculated missing values.");
                System.out.println("Original:\t" +
                        originInstance.value(39) + ",\t" +
                        originInstance.value(40) + ",\t" +
                        originInstance.value(41) + ",\t" +
                        originInstance.value(43) + ",\t" +
                        originInstance.value(44) + ",\t" +
                        originInstance.value(45) + ",\t" +
                        originInstance.value(46) + ",\t" +
                        originInstance.value(50)
                );
//                Instance calculatedInstance = dataSet.instance(row);
//                System.out.println("Calculated:\t" +
//                        calculatedInstance.value(39) + ",\t" +
//                        calculatedInstance.value(40) + ",\t" +
//                        calculatedInstance.value(41) + ",\t" +
//                        calculatedInstance.value(43) + ",\t" +
//                        calculatedInstance.value(44) + ",\t" +
//                        calculatedInstance.value(45) + ",\t" +
//                        calculatedInstance.value(46) + ",\t" +
//                        calculatedInstance.value(50)
//                );
            Instance allPredictedInstance = predictedDataset.instance(row);
            System.out.println("Predicted:\t" +
                    allPredictedInstance.value(39) + ",\t" +
                    allPredictedInstance.value(40) + ",\t" +
                    allPredictedInstance.value(41) + ",\t" +
                    allPredictedInstance.value(43) + ",\t" +
                    allPredictedInstance.value(44) + ",\t" +
                    allPredictedInstance.value(45) + ",\t" +
                    allPredictedInstance.value(46) + ",\t" +
                    allPredictedInstance.value(50)
            );
                System.out.println("--------------------------------------------------------------------------");
            }

        Evaluation eval = new Evaluation(trainingData);
        eval.evaluateModel(randomForest,predictedDataset);
        System.out.println(eval.toSummaryString("\nResults\n========================================\n", true));
        return dataSet;
    }

    public static void saveDataSet(Instances dataSet, String path) throws java.lang.Exception {
        CSVSaver csvSaver = new CSVSaver();
        csvSaver.setInstances(dataSet);
        csvSaver.setFile(new File(path + ".csv"));
        csvSaver.writeBatch();

        ArffSaver arffSaver = new ArffSaver();
        arffSaver.setInstances(dataSet);
        arffSaver.setFile(new File(path + ".arff"));
        arffSaver.writeBatch();
    }

    public static double round(double value, int places) {
        double scale = Math.pow(10, places);
        return Math.round(value * scale) / scale;
    }

    public static RandomForest createRandomForest(int numberOfTrees , int depthOfTrees , int minVarianceForSplit) {
        RandomForest rf = new RandomForest();
        String[] rfOptions = new String[6];
        rfOptions[0] = "-I";
        rfOptions[1] = ""+numberOfTrees;
        rfOptions[2] = "-depth";
        rfOptions[3] = ""+depthOfTrees;
        rfOptions[4] = "-V";
        rfOptions[5] = ""+minVarianceForSplit;
        try {
            rf.setOptions(rfOptions);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rf;
    }

    public static Instances filterUnsupervisedAttributes(Instances dataSet) {
        try {
            RemoveType removeType = new RemoveType();
            removeType.setInputFormat(dataSet);
            return Filter.useFilter(dataSet, removeType);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean predictTargetColumn(Instances dataSet, Instances trainingData, int rowIndex, int targetColumnIndex, RandomForest randomForest,Instances  predictedDataset) {
        // set target column for prediction
        Instance instance = dataSet.instance(rowIndex);
        boolean isTargetColumnAtCurrentRowMissing = instance.isMissing(targetColumnIndex);
        try {

                // same block //
                dataSet.setClassIndex(targetColumnIndex);
                trainingData.setClassIndex(targetColumnIndex);
                predictedDataset.setClassIndex(targetColumnIndex);
//                RandomForest randomForest = createRandomForest(NUMBER_OF_TREES);
                randomForest.buildClassifier(trainingData);
                double predictedValue = round(randomForest.classifyInstance(instance),2);
                // end block //
            if (isTargetColumnAtCurrentRowMissing) {  // set predicted value in both origin and training data sets
                instance.setValue(targetColumnIndex, predictedValue);
                dataSet.set(rowIndex, instance);
                trainingData.set(rowIndex, instance);
            } // either missing or not put in this dataset just for evaluation.
                Instance tempInstance = (Instance)instance.copy();
                tempInstance.setValue(targetColumnIndex, predictedValue);
                predictedDataset.set(rowIndex,tempInstance);


        } catch (Exception e) {
            e.printStackTrace();
        }
        return isTargetColumnAtCurrentRowMissing;
    }

    public static void evaluateOriginalDatasetByRF(String path ) throws java.lang.Exception {
        ConverterUtils.DataSource dataSource = new ConverterUtils.DataSource(RAW_DATA);
        Instances originalDataSet = dataSource.getDataSet();

        Instances trainingData = new Instances(dataSource.getStructure());
        Instances predictedDataset = dataSource.getDataSet();
        originalDataSet = filterUnsupervisedAttributes(originalDataSet);
        predictedDataset = filterUnsupervisedAttributes(predictedDataset);
        trainingData = filterUnsupervisedAttributes(trainingData);

        RandomForest randomForest = createRandomForest(NUMBER_OF_TREES, DEPTH_OF_TREES, MIN_VARIANCE_FOR_SPLIT);
        BufferedWriter br = new BufferedWriter(new FileWriter(EACH_500_EVALUATION_FILE_PATH));
        double[][] temporarySpaceToWrite = new double[15][3] ;
        int numInst = originalDataSet.numInstances();
        int i = 0;
        for (int row = 0; row < numInst; row++) {
            long start = System.currentTimeMillis();
            int numMissingValues = 0;
            // save predicted values every 500 rows to use as training instances for the next 500 inatances.
            if (row > 0 && row % 500 == 0) {
                weka.classifiers.Evaluation eval = new weka.classifiers.Evaluation(trainingData);
                eval.evaluateModel(randomForest, predictedDataset);
                System.out.println(eval.toSummaryString("\nResults\n========================================\n", true));
                temporarySpaceToWrite[i][0]=row;
                temporarySpaceToWrite[i][1]=round(eval.meanAbsoluteError(),2);
                temporarySpaceToWrite[i][2]=round(eval.rootMeanSquaredError(),2);
                i++;


                saveDataSet(predictedDataset, "/Users/ali/Desktop/COMPSCI791A/Predicted_First_" + row + "_rows");
                randomForest = createRandomForest(NUMBER_OF_TREES, DEPTH_OF_TREES, MIN_VARIANCE_FOR_SPLIT);

            }



            Instance originInstance = (Instance) originalDataSet.instance(row).copy();
            trainingData.add(originInstance);

            if (predictTargetColumn(originalDataSet, trainingData, row, 40, randomForest, predictedDataset))
                numMissingValues++;
            if (predictTargetColumn(originalDataSet, trainingData, row, 41, randomForest, predictedDataset))
                numMissingValues++;
            if (predictTargetColumn(originalDataSet, trainingData, row, 44, randomForest, predictedDataset))
                numMissingValues++;
            if (predictTargetColumn(originalDataSet, trainingData, row, 46, randomForest, predictedDataset))
                numMissingValues++;
            if (predictTargetColumn(originalDataSet, trainingData, row, 50, randomForest, predictedDataset))
                numMissingValues++;

            if (row > 5022) {
                if (predictTargetColumn(originalDataSet, trainingData, row, 39, randomForest, predictedDataset))
                    numMissingValues++;
            }
            if (row > 130) {
                if (predictTargetColumn(originalDataSet, trainingData, row, 43, randomForest, predictedDataset))
                    numMissingValues++;
            }
            if (row > 57) {
                if (predictTargetColumn(originalDataSet, trainingData, row, 45, randomForest, predictedDataset))
                    numMissingValues++;
            }


            long end = System.currentTimeMillis();
            System.out.println("Row #" + row + " is processed in " + (end - start) + " milllis with " + numMissingValues + " calculated missing values.");
            System.out.println("Original:\t" +
                    originInstance.value(39) + ",\t" +
                    originInstance.value(40) + ",\t" +
                    originInstance.value(41) + ",\t" +
                    originInstance.value(43) + ",\t" +
                    originInstance.value(44) + ",\t" +
                    originInstance.value(45) + ",\t" +
                    originInstance.value(46) + ",\t" +
                    originInstance.value(50)
            );

            Instance allPredictedInstance = predictedDataset.instance(row);
            System.out.println("Predicted:\t" +
                    allPredictedInstance.value(39) + ",\t" +
                    allPredictedInstance.value(40) + ",\t" +
                    allPredictedInstance.value(41) + ",\t" +
                    allPredictedInstance.value(43) + ",\t" +
                    allPredictedInstance.value(44) + ",\t" +
                    allPredictedInstance.value(45) + ",\t" +
                    allPredictedInstance.value(46) + ",\t" +
                    allPredictedInstance.value(50)
            );
            System.out.println("--------------------------------------------------------------------------");



        }
        writeEach500EvalResult( br, temporarySpaceToWrite);
        br.close();
    }
    public static void writeEach500EvalResult(BufferedWriter br, double[][] result) throws Exception  {

        StringBuilder sb = new StringBuilder();
        sb.append("Row,MAE,RMSE");
        sb.append(System.getProperty("line.separator"));
        for(int i=0;i<result.length;i++){
            for(int j =0;j<result[i].length;j++){
                sb.append(result[i][j]);
                sb.append(",");
            }
            sb.append(System.getProperty("line.separator"));

        }

        br.write(sb.toString());

    }



}


